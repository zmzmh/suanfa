package src;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@SuppressWarnings("ALL")
public class Runner {
	static String[] splits;//临时装载变量
	static String[] splitss;//临时装载变量
	static String[] sp;//存放转换后的数组对象
	static int[][][] a;// 将字符数字转成整形，按格式存入数组
	static int constraints; 			// 给定的约束
	static int dimensions = 0; // 给定的维度个数：商品个数
	static double givevalue = 0; // 给定的价格
	static String[][] flags;  //算法路径记录表
	static int[][] flagss; //价值记录表

	public static void main(String[] args) {
		int[][][] gg = initData();
		int wh = gg[0].length; // 记录二维的行数
		flags = new String[wh][wh * wh * wh * wh * wh];
		flagss = new int[wh][wh * wh * wh * wh * wh];
		for (int iss = 0; iss < wh; iss++) {        // 输出读取好的数据
			for (int is = 0; is < gg[0].length; is++) {
				System.out.print(gg[0][iss][is] + " ");
			}
			System.out.println();
		}
		for (int i = 0; i < wh - 2; i++) {
			System.out.println("<========第" + (i + 1) + "个约束的可选算法与价值======>");
			constraints = gg[0][wh - 1][i]; // 当前的限制条件
			Algorithm a = new Algorithm(constraints, givevalue, dimensions, gg[0][i + 1], gg[0][0], i, flags, flagss);//算法实现
			a.b(0);
		}
		int as = Integer.parseInt(flags[0][0]);
		int aas = 1;
		String ap = "";
		int app = 0;
		//输出路径与价格
		for (int i = 0; i < as; i++) {
			String u = flags[0][as];          //从第一行的最后一个开始
			for (int j = 1; j < wh - 2; j++) {
				for (int k = Integer.parseInt(flags[j][0]); k >= 1; k--) { // 数组的第一个元素为最优解的个数
					//遍历子集是否相等
					if (u.equals(flags[j][k])) {
						ap = u;      //记录路径
						app = flagss[j][k - 1];  //记录价值
						aas++;   //存在判断
					} else
						continue;
				}
			}
			if (as > 1) as--;
		}
		if (aas >= wh - 2) {
			System.out.println("最优的算法选择为：" + ap + "  ");
			System.out.println("最优的价值为：" + app);
			System.out.print("选择：   ");
			for (int j = 0; j < ap.length(); j++) {
				char tem = ap.charAt(j);
				if (tem == '1')  System.out.print((j + 1) + "号  ");// 空格
			}
			System.out.print("商品");
		} else
			System.out.println("没有噢");
	}


	public static int[][][] initData() {
		int i = 0;
		try {
			System.out.println("请请输入商品数n和约束数m及最大价值x:");
			Scanner scanner = new Scanner(System.in);
			String fnums = scanner.nextLine();
			String s = fnums;
			String[] basicData = s.split(" "); 	//存放商品数+约束数+最大价值
			dimensions = Integer.parseInt(basicData [0]); // 读取出商品个数
			givevalue = Integer.parseInt(basicData [2]); // 读取价格
			splitss = new String[Integer.parseInt(basicData [1]) + 2]; // 计算总行数=商品个数+约束+结果
			sp = new String[Integer.parseInt(basicData [0])]; // 除去第一行有多少行
			a = new int[1][Integer.parseInt(basicData [1]) + 2][Integer.parseInt(basicData [0]) * Integer.parseInt(basicData [0]) * 2]; // 转换成二维数组

			System.out.println("请输入" + basicData [0] + "个商品价格，用空格隔开：");
			String price = scanner.nextLine();//价格
			List<String> list = new ArrayList<>();
			list.add(price);
			System.out.println("请输入" + basicData [0] + "个商品的" + basicData [1] + "个约束");
			for (int i1 = 0; i1 < Integer.valueOf(basicData [1]); i1++) {
				System.out.println("请输入第" + (i1 + 1) + "个约束：");
				String strp = scanner.nextLine();
				list.add(strp);
			}
			System.out.println("请输入" + basicData [0] + "个商品的约束值：");
			String constraint = scanner.nextLine();
			list.add(constraint);
			// 循环读数据
			for (String str : list) {
				splits = str.split("\n");
				splitss[i] = splits[0];
				int count = 0;// 统计空格个数
				// 以空格为分隔符
				for (int j = 0; j < splitss[i].length(); j++) {
					char tem = str.charAt(j);
					if (tem == ' ') count++; // 空格
				}
				sp = splitss[i].split(" ");
				for (int k = 0; k < count + 1; k++) {// 取出元素
					a[0][i][k] = Integer.parseInt(sp[k]);// 将字符数字转成整形，按格式存入数组
				}
				i++;
			}
			return a;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
